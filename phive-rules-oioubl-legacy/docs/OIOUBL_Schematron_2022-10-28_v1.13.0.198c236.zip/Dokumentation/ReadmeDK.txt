ReadmeDK.txt
Revideret - 1.13.0 (28.10.2022).


OIOUBL-2.1 schematron validerings-stylesheets
----------------------------------------------


1.0 Anvendelse
--------------
Anvendes til at validere om XML eksempelfil overholder reglerne i OIOUBL subset.
Følgende OIOUBL dokumenttyper kan valideres:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml
    UtilityStatement.xml

Et dokument, f.eks. en faktura, kan valideres således:
msxsl.exe <XML dokument filnavn> OIOUBL_Invoice_Schematron.xsl -o resultat.xml

Hvis fakturaen validerer OK skrives alene en overskrift til resultat.xml, ellers listes alle fundne fejl.


2.0 Forudsætninger
------------------
Det forudsættes at eksempelfilen er valideret korrekt med det tilhørende UBL-2.1 XSD schema inden schematron stylesheetet anvendes.


3.0 Release Notes
-----------------
Schematron ændringer fra 1.12.3 til 1.13

Funktionelle / tekniske ændringer:
- NH-2005: Valideringen af momskategorien = "StandardRated" og moms-procenten ="0.00" da dette ikke er tilladt
- UAN-196: Opdateringen af UTS schematron, således at OASIS/UBL XSD ver. 2.1 benyttes, frem for gammel dansk lokalisering. Opdatering indeholder  en dynamisk funktion som vælger
           den korrekte UTS XSL baseret på dagsdato

		   For at benytte den dynamiske funktion vil følgende være nødvendig
		   - "OIOUBL_UtilityStatement_Master" skal bruges som XSL for UTS
		   - Sikre at nedenstående XSL'er er i samme folder som "OIOUBL_UtilityStatement_Master.xsl"
		      - Gammeel UTS XSL: OIOUBL_UtilityStatement_Schematron2.1b.xsl (Gammel XSL fil - Tilladt indtil den 30-11-2022)
		      - Ny UTS XSL: OIOUBL_UtilityStatement_Schematron2.1.xsl (Ny XSL fil - Krav fra  den 30-11-2022)

		   Hvis man ikke ønsker at bruge den dynamiske funktionalitet, skal man sikre at nedenstående XLS lægges i produktion den 30-11-2022
		   - UTS XSL: OIOUBL_UtilityStatement_Schematron.xsl

- NH-1872: Tillad OriginCountry i OIOUBL Catalogue
- NH-2338: Fejlrettelse af validering af Payableaomunt [F-INV133]
- NH-2142: Opdatering af alle OIOUBL schematroner til XLST ver. 2.0


Schematron ændringer fra 1.12.2 til 1.12.3:

Funktionelle / tekniske ændringer:
- NH-2008: Opdatering af validering af CustomizationID således at 'OIOUBL-2.00' ikke er tilladt


4.0 Revisionslog
----------------
2016.09.15  Version 1.8.0 frigivet.
2017.09.15  Version 1.9.0 frigivet.
2018.09.15  Version 1.10.0 frigivet.
2019.04.08  Version 1.11.1 frigivet.
2022.01.15  Version 1.12.DEV betaversion
2022.03.10  Version 1.12.RC1 ReleaseCandidate
2022.04.06  Version 1.12 frigivet
2022.05.11  Version 1.12.2 frigivet
2022.05.19  Version 1.12.3 frigivet
2022.09.30  Version 1.13.0.RC1 Release Candidate
2022.10.28  Version 1.13.0 frigivet.

5.0 Rapportering af fejl og mangler etc.
----------------------------------------
Information om fejl, mangler, og andet relevant, sendes til:
    support@nemhandel.dk

På forhånd tak!
