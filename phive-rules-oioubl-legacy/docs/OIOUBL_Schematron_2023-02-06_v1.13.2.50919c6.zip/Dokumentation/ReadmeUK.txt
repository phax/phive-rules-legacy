ReadmeUK.txt
Revision - 1.13.2 (18.01.2023).



OIOUBL-2.1 schematron stylesheet
----------------------------------


1.0 Purpose and usage
---------------------
Validation of OIOUBL instances.
The following OIOUBL document types are currently supported:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml
    UtilityStatement.xml

To validate, execute the following command (shown for Invoice):
msxsl.exe <XML document filename> OIOUBL_Invoice_Schematron.xsl -o result.xml

If the validation is successful, only the title is written to result.xml; otherwise the errors are listed.



2.0 Prerequisites
-----------------
The instance file must validate OK with the UBL-2.1 XSD schema.


3.0 Release Notes
---------------------
Changes from version 1.13.1 to 1.13.2
- NH-3462: Update OIOUBL_UtilityStatement_Schematron2.1.xsl to match validation in OIOUBL_UtilityStatement_Schematron.xml
- NH-3466: F-LIB312 Has been redesiged to valide for "InstructionID must not be blank" and a new rule (F-LIB390) has been introduced and validate for "InstructionID must be numeric.".


Functional / technical changes:
- NH-3421: F-LIB336 & F-LIB312 The validation is updated to fail if "cbc:InstructionID" contain + or -
- NH-3424: F-LIB381 updates to ensure correct validation even is negativ 0 in cbc:TaxAmount
- NH-3423: Update of F-LIB382 to ensure correct validation aganist "cbc:Percent"
- NH-3168/NH-3158: Support for multiple AllowanceCharge in Invoice, Order Response & UTS (error correction after update to XSLT 2.0)
- NH-3089: Error correction regarding formatting of cac:Price/cbc:BaseQuantity to two decimals removed in Invoice, CreditNote & Order
- NH-3188: Error correction regarding formatting of cac:Price/cbc:OrderableUnitFactorRate to two decimals removed in Invoice, CreditNote & Order.
- NH-3033: Support for several "OtherCommunication"
- NH-3210: Error correction: Variable "BaseQuantity" is set to 1 if the element "cbc:baseQuantity" is missing in segment "cac:Price"
- NH-3198: Reintroduce validation of F-INV335 for cac:AllowanceCharge on linelevel (Negative ”amount”)
- NH-3247: Use of ”following-sibling::” in the validation of "LanguageID" on "Description" can return false result (W-LIB222), if other elements fx. "Name" use "LanguageID"
- UAN-196: Date for dynamic choose of UTS has been moved to 06-02-23

Changes from version 1.12.3 to 1.13

Functional / technical changes:
- NH-2005: Validation of "VAT category" = 'StandardRated' and "VAT-precent" ='0.00' which is not allowed
- UAN-196: Update of OIOUBL Utllity Statement to OASIS/UBL XSD ver. 2.1 - Including a dynamic function where the
           correct UTS XSL is choosen based on current date

           To use the dynamic function you will need to
           - Use the "OIOUBL_UtilityStatement_Master" as the main XSL for UTS
           - Ensure that the XSL's below are in the same folder as the "OIOUBL_UtilityStatement_Master.xsl"
           	- Old UTS XSL: OIOUBL_UtilityStatement_Schematron2.1b.xsl (Valid until 30-11-2022)
           	- New UTS XSL: OIOUBL_UtilityStatement_Schematron2.1.xsl (Mandatory from 30-11-2022)

           If the dynamic function is not to be used then just ensure that the XLS below are set into production the 30-11-2022
           - UTS XSL: OIOUBL_UtilityStatement_Schematron.xsl

- NH-1872: Allow "OriginCountry" in OIOUBL Catalogue
- NH-2338: Error correction of validation of Payableaomunt [F-INV133]
- NH-2142: Update of all OIOUBL schematrons to be able to support XLST ver. 2.0


Changes from version 1.12.2 to 1.12.3:

Functional / technical changes:
- NH-2008: Update of validation of CustomizationID to ensure that 'OIOUBL-2.00' are not allowed


4.0 Revision log
----------------
2016.09.15  Version 1.8.0 released.
2017.09.15  Version 1.9.0 released.
2018.09.15  Version 1.10.0 released.
2019.04.08  Version 1.11.1 released.
2022.01.15  Version 1.12.DEV betaversion
2022.03.10  Version 1.12.RC1 ReleaseCandidate
2022.04.06  Version 1.12 released
2022.05.11  Version 1.12.2 released
2022.05.19  Version 1.12.3 released
2022.09.30  Version 1.13.0 ReleaseCandidate
2022.10.28  Version 1.13.0 Released
2023.01.06  Version 1.13.1 Released
2023.01.18  Version 1.13.2 Released


5.0 Your feedback
-----------------
Please post your comments and feedback to:
    support@nemhandel.dk

Thanks!
